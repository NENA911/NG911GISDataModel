from . import logger

# logger modules
CreateLogger = logger.create_logger
DeleteOldLogs = logger.delete_old_logs
